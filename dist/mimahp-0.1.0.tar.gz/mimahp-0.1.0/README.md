# mimAHP
A Python library that enables fast execution of the Analytical Hierarchy Process.
